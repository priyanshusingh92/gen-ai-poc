import { AppDataSource } from '../config/database.config'
import { Parameters } from '../entities/Parameters.entity'

/**
 * Uses a lazy getter so getRepository() is only called after DataSource is initialised.
 */
class ParametersRepository {
  private get repo() {
    return AppDataSource.getRepository(Parameters)
  }

  async findByVersion(version: number): Promise<Parameters | null> {
    return this.repo.findOne({ where: { version } })
  }

  async findAll(): Promise<Parameters[]> {
    return this.repo.find({ order: { version: 'ASC' } })
  }

  async save(entity: Parameters): Promise<Parameters> {
    return this.repo.save(entity)
  }
}

export const parametersRepository = new ParametersRepository()
