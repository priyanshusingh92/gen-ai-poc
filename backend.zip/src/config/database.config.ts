import 'reflect-metadata'
import { DataSource } from 'typeorm'
import { Parameters } from '../entities/Parameters.entity'
import dotenv from 'dotenv'

dotenv.config()

export const AppDataSource = new DataSource({
  type: 'mariadb',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  username: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'parameters_db',
  // synchronize: true auto-creates/updates tables from entities — disable in production, use migrations instead
  synchronize: process.env.NODE_ENV !== 'production',
  logging: process.env.DB_LOGGING === 'true',
  entities: [Parameters],
})
