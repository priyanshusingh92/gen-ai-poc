import 'reflect-metadata'
import dotenv from 'dotenv'
dotenv.config()

import express from 'express'
import cors from 'cors'
import { AppDataSource } from './config/database.config'
import { logger } from './config/logger.config'
import { parametersRouter } from './routes/parameters.routes'
import { errorHandler } from './middleware/errorHandler.middleware'
import { requestLogger } from './middleware/requestLogger.middleware'

const app = express()
const PORT = parseInt(process.env.PORT || '3000', 10)

// ── Global middleware ────────────────────────────────────────────────────────
app.use(cors())
app.use(express.json())
app.use(requestLogger)

// ── Routes ───────────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

app.use('/api/parameters', parametersRouter)

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'NotFound', message: 'Route not found' })
})

// ── Centralized error handler (must be last) ─────────────────────────────────
app.use(errorHandler)

// ── Bootstrap ────────────────────────────────────────────────────────────────
AppDataSource.initialize()
  .then(() => {
    logger.info('Database connection established')
    app.listen(PORT, () => {
      logger.info(`Server running on http://localhost:${PORT}`)
      logger.info(`Health check: GET http://localhost:${PORT}/health`)
      logger.info(`Parameters API: http://localhost:${PORT}/api/parameters/:version`)
    })
  })
  .catch((err: Error) => {
    logger.error('Failed to connect to database', err)
    process.exit(1)
  })

export default app
