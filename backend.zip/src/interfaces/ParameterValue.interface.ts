export interface ClassificationDetail {
  weight: number
  high: number
  medium: number
  low: number
}

export interface EffortItem {
  id: number
  component: string
  New: ClassificationDetail
  Enhanced: ClassificationDetail
  Reuse: ClassificationDetail
  Decom: ClassificationDetail
}

export interface WorkItem {
  id: number
  item: string
  value: number
  aSplit: number
  bSplit: number
}

export interface CostItem {
  id: number
  item: string
  value: number
  aSplit: number
  bSplit: number
}

// SHARED_ITEM (typed as SHARED_TEM per spec — key name preserved)
export interface SharedItem {
  id: number
  item: string
  value: number
  aSplit: number
  bSplit: number
}

export interface VendorEntry {
  id: number
  vendorName: string
  rate: number
  checkStatus: boolean
}

export interface VendorConfig {
  id: number
  localRate: number
  vendorRate: number
  vendors: VendorEntry[]
}

export interface ParameterValue {
  Effort: EffortItem[]
  WORK_ITEM: WorkItem[]
  COST_ITEM: CostItem[]
  SHARED_ITEM: SharedItem[]
  VENDOR: VendorConfig
}

export type ValueKey = keyof ParameterValue

export const ARRAY_KEYS: ValueKey[] = ['Effort', 'WORK_ITEM', 'COST_ITEM', 'SHARED_ITEM']
