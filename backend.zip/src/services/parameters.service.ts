import { parametersRepository } from '../repositories/parameters.repository'
import { Parameters } from '../entities/Parameters.entity'
import {
  ParameterValue,
  ValueKey,
  ARRAY_KEYS,
  VendorEntry,
  EffortItem,
  WorkItem,
  CostItem,
  SharedItem,
} from '../interfaces/ParameterValue.interface'
import { NotFoundError, ValidationError } from '../middleware/errorHandler.middleware'

type ArrayItem = EffortItem | WorkItem | CostItem | SharedItem

// ── Helpers ─────────────────────────────────────────────────────────────────

function isArrayKey(type: ValueKey): boolean {
  return ARRAY_KEYS.includes(type)
}

function nextId(items: ArrayItem[]): number {
  return items.reduce((max, item) => Math.max(max, item.id), 0) + 1
}

// ── Service ──────────────────────────────────────────────────────────────────

class ParametersService {
  // ── GET by version ──────────────────────────────────────────────────────

  async getByVersion(version: number): Promise<Parameters> {
    if (isNaN(version)) throw new ValidationError('Version must be a valid number')

    const record = await parametersRepository.findByVersion(version)
    if (!record) throw new NotFoundError(`No parameters found for version ${version}`)

    return record
  }

  // ── PUT — upsert a single item within a value key ───────────────────────

  async updateItem(
    version: number,
    type: ValueKey,
    newValue: Record<string, unknown>,
    editedBy: string = 'system',
  ): Promise<Parameters> {
    if (!type) throw new ValidationError('type is required')
    if (!newValue) throw new ValidationError('newValue is required')

    const record = await this.getByVersion(version)

    // Deep-clone value to avoid mutating the cached entity reference
    const value: ParameterValue = JSON.parse(JSON.stringify(record.value))

    if (type === 'VENDOR') {
      // Replace entire VENDOR object
      value.VENDOR = newValue as unknown as typeof value.VENDOR
    } else if (isArrayKey(type)) {
      const array = value[type] as ArrayItem[]
      const incomingId = newValue.id as number | undefined

      if (incomingId !== undefined && incomingId !== null) {
        const idx = array.findIndex((item) => item.id === incomingId)
        if (idx >= 0) {
          // Replace existing item
          array[idx] = newValue as unknown as ArrayItem
        } else {
          // id provided but not found — treat as new, assign generated id
          array.push({ ...newValue, id: nextId(array) } as unknown as ArrayItem)
        }
      } else {
        // No id — new item, assign generated id
        array.push({ ...newValue, id: nextId(array) } as unknown as ArrayItem)
      }

      // TypeScript narrowing: assign back to correct key
      (value[type] as ArrayItem[]) = array
    } else {
      throw new ValidationError(`Unknown type: ${type}`)
    }

    record.value = value
    record.last_edit_by = editedBy
    record.last_edit_time = new Date()

    return parametersRepository.save(record)
  }

  // ── DELETE — remove an item from a value key ─────────────────────────────

  async deleteItem(
    version: number,
    type: ValueKey,
    deletionId: number,
    editedBy: string = 'system',
  ): Promise<Parameters> {
    if (!type) throw new ValidationError('type is required')
    if (deletionId === undefined || deletionId === null)
      throw new ValidationError('deletionId is required')

    const record = await this.getByVersion(version)
    const value: ParameterValue = JSON.parse(JSON.stringify(record.value))

    if (type === 'VENDOR') {
      // Remove from nested vendors array
      value.VENDOR.vendors = value.VENDOR.vendors.filter((v: VendorEntry) => v.id !== deletionId)
    } else if (isArrayKey(type)) {
      const array = value[type] as ArrayItem[]
      ;(value[type] as ArrayItem[]) = array.filter((item) => item.id !== deletionId)
    } else {
      throw new ValidationError(`Unknown type: ${type}`)
    }

    record.value = value
    record.last_edit_by = editedBy
    record.last_edit_time = new Date()

    return parametersRepository.save(record)
  }
}

export const parametersService = new ParametersService()
