import { Router } from 'express'
import { parametersController } from '../controllers/parameters.controller'

export const parametersRouter = Router()

// GET /api/parameters/:version
parametersRouter.get('/:version', (req, res, next) =>
  parametersController.getByVersion(req, res, next),
)

// PUT /api/parameters
parametersRouter.put('/', (req, res, next) =>
  parametersController.updateItem(req, res, next),
)

// DELETE /api/parameters
parametersRouter.delete('/', (req, res, next) =>
  parametersController.deleteItem(req, res, next),
)
