import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm'
import { ParameterValue } from '../interfaces/ParameterValue.interface'

@Entity('parameters')
export class Parameters {
  @PrimaryGeneratedColumn()
  id!: number

  @Column({ type: 'int', unique: true })
  version!: number

  @Column({ name: 'project_count', type: 'int', default: 0 })
  project_count!: number

  @Column({ type: 'json' })
  value!: ParameterValue

  @Column({ name: 'last_edit_by', type: 'varchar', length: 255 })
  last_edit_by!: string

  @Column({ name: 'last_edit_time', type: 'timestamp' })
  last_edit_time!: Date

  @CreateDateColumn({ name: 'created_date', type: 'timestamp' })
  created_date!: Date
}
