import { Request, Response, NextFunction } from 'express'
import { parametersService } from '../services/parameters.service'
import { ValueKey } from '../interfaces/ParameterValue.interface'

class ParametersController {
  /**
   * GET /api/parameters/:version
   * Returns the parameters record for the given version.
   */
  async getByVersion(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const version = parseInt(req.params.version, 10)
      const data = await parametersService.getByVersion(version)
      res.json({ success: true, data })
    } catch (err) {
      next(err)
    }
  }

  /**
   * PUT /api/parameters
   * Body: { version, type, newValue, editedBy? }
   * Upserts a single item within value[type].
   */
  async updateItem(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { version, type, newValue, editedBy } = req.body as {
        version: number
        type: ValueKey
        newValue: Record<string, unknown>
        editedBy?: string
      }
      const data = await parametersService.updateItem(version, type, newValue, editedBy)
      res.json({ success: true, data, message: 'Parameter updated successfully' })
    } catch (err) {
      next(err)
    }
  }

  /**
   * DELETE /api/parameters
   * Body: { version, type, deletionId, editedBy? }
   * Removes an item with deletionId from value[type].
   */
  async deleteItem(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { version, type, deletionId, editedBy } = req.body as {
        version: number
        type: ValueKey
        deletionId: number
        editedBy?: string
      }
      const data = await parametersService.deleteItem(version, type, deletionId, editedBy)
      res.json({ success: true, data, message: 'Parameter deleted successfully' })
    } catch (err) {
      next(err)
    }
  }
}

export const parametersController = new ParametersController()
