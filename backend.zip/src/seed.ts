import 'reflect-metadata'
import dotenv from 'dotenv'
dotenv.config()

import { AppDataSource } from './config/database.config'
import { Parameters } from './entities/Parameters.entity'
import { ParameterValue } from './interfaces/ParameterValue.interface'
import { logger } from './config/logger.config'

const waterfallValue: ParameterValue = {
  Effort: [
    {
      id: 1,
      component: 'Requirements',
      New: { weight: 1.0, high: 100, medium: 80, low: 60 },
      Enhanced: { weight: 0.5, high: 50, medium: 40, low: 30 },
      Reuse: { weight: 0.3, high: 30, medium: 20, low: 15 },
      Decom: { weight: 0.2, high: 20, medium: 15, low: 10 },
    },
    {
      id: 2,
      component: 'Development',
      New: { weight: 1.0, high: 200, medium: 160, low: 120 },
      Enhanced: { weight: 0.6, high: 120, medium: 96, low: 72 },
      Reuse: { weight: 0.2, high: 40, medium: 32, low: 24 },
      Decom: { weight: 0.1, high: 20, medium: 16, low: 12 },
    },
  ],
  WORK_ITEM: [
    { id: 1, item: 'Story Points', value: 8, aSplit: 50, bSplit: 50 },
    { id: 2, item: 'Function Points', value: 12, aSplit: 45, bSplit: 55 },
  ],
  COST_ITEM: [
    { id: 1, item: 'SIT Support', value: 15, aSplit: 30, bSplit: 70 },
    { id: 2, item: 'UAT Support', value: 10, aSplit: 30, bSplit: 70 },
    { id: 3, item: 'Production Implementation Support', value: 5, aSplit: 30, bSplit: 70 },
    { id: 4, item: 'Warranty Support', value: 5, aSplit: 30, bSplit: 70 },
  ],
  SHARED_ITEM: [
    { id: 1, item: 'Project Management', value: 10, aSplit: 60, bSplit: 40 },
    { id: 2, item: 'Architecture Review', value: 5, aSplit: 50, bSplit: 50 },
  ],
  VENDOR: {
    id: 1,
    localRate: 100,
    vendorRate: 150,
    vendors: [
      { id: 1, vendorName: 'Vendor A', rate: 150, checkStatus: true },
      { id: 2, vendorName: 'Vendor B', rate: 120, checkStatus: false },
    ],
  },
}

const agileValue: ParameterValue = {
  Effort: [
    {
      id: 1,
      component: 'Sprint Planning',
      New: { weight: 0.8, high: 80, medium: 64, low: 48 },
      Enhanced: { weight: 0.4, high: 40, medium: 32, low: 24 },
      Reuse: { weight: 0.2, high: 20, medium: 16, low: 12 },
      Decom: { weight: 0.1, high: 10, medium: 8, low: 6 },
    },
  ],
  WORK_ITEM: [
    { id: 1, item: 'User Story', value: 5, aSplit: 50, bSplit: 50 },
    { id: 2, item: 'Epic', value: 40, aSplit: 45, bSplit: 55 },
    { id: 3, item: 'Task', value: 2, aSplit: 50, bSplit: 50 },
  ],
  COST_ITEM: [
    { id: 1, item: 'Sprint Support', value: 8, aSplit: 35, bSplit: 65 },
    { id: 2, item: 'Release Support', value: 12, aSplit: 30, bSplit: 70 },
    { id: 3, item: 'Go-Live Support', value: 6, aSplit: 30, bSplit: 70 },
  ],
  SHARED_ITEM: [
    { id: 1, item: 'Scrum Master', value: 8, aSplit: 55, bSplit: 45 },
    { id: 2, item: 'DevOps Support', value: 7, aSplit: 45, bSplit: 55 },
  ],
  VENDOR: {
    id: 1,
    localRate: 120,
    vendorRate: 170,
    vendors: [
      { id: 1, vendorName: 'Scrum Coach', rate: 170, checkStatus: true },
      { id: 2, vendorName: 'Agile Developer', rate: 120, checkStatus: true },
    ],
  },
}

async function seed() {
  await AppDataSource.initialize()
  logger.info('Database connected — running seed...')

  const repo = AppDataSource.getRepository(Parameters)
  const now = new Date()

  const records = [
    {
      version: 1,
      project_count: 0,
      value: waterfallValue,
      last_edit_by: 'seed',
      last_edit_time: now,
    },
    {
      version: 2,
      project_count: 0,
      value: agileValue,
      last_edit_by: 'seed',
      last_edit_time: now,
    },
  ]

  for (const record of records) {
    const existing = await repo.findOne({ where: { version: record.version } })
    if (existing) {
      logger.info(`Version ${record.version} already exists — skipping`)
    } else {
      await repo.save(record)
      logger.info(`Seeded version ${record.version}`)
    }
  }

  await AppDataSource.destroy()
  logger.info('Seed complete')
}

seed().catch((err) => {
  logger.error('Seed failed', err)
  process.exit(1)
})
