import { useState } from 'react'
import './SystemParameters.css'

const TABS = [
  'Effort Driver',
  'FP/SP per Work Item',
  'Support Costs',
  'Shared Services & Delivery Management Costs',
  'Vendor PS Rates',
]

const INITIAL_ROWS = [
  { id: 1, item: 'SIT Support', value: '15%', sdmSplit: '30%', psSplit: '70%' },
  { id: 2, item: 'UAT Support', value: '10%', sdmSplit: '30%', psSplit: '70%' },
  { id: 3, item: 'Production Implementation Support', value: '5%', sdmSplit: '30%', psSplit: '70%' },
  { id: 4, item: 'Warranty Support', value: '5%', sdmSplit: '30%', psSplit: '70%' },
]

let nextId = 5

export default function SystemParameters() {
  const [methodology, setMethodology] = useState('Waterfall')
  const [activeTab, setActiveTab] = useState('Support Costs')
  const [rows, setRows] = useState(INITIAL_ROWS)
  const [search, setSearch] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editValues, setEditValues] = useState({})

  const filtered = rows.filter((r) =>
    Object.values(r).some((v) =>
      String(v).toLowerCase().includes(search.toLowerCase())
    )
  )

  function handleAdd() {
    const newRow = { id: nextId++, item: 'New Item', value: '0%', sdmSplit: '0%', psSplit: '0%' }
    setRows((prev) => [...prev, newRow])
    setEditingId(newRow.id)
    setEditValues({ item: newRow.item, value: newRow.value, sdmSplit: newRow.sdmSplit, psSplit: newRow.psSplit })
  }

  function handleDelete(id) {
    setRows((prev) => prev.filter((r) => r.id !== id))
    if (editingId === id) setEditingId(null)
  }

  function handleEditStart(row) {
    setEditingId(row.id)
    setEditValues({ item: row.item, value: row.value, sdmSplit: row.sdmSplit, psSplit: row.psSplit })
  }

  function handleEditSave(id) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...editValues } : r)))
    setEditingId(null)
  }

  function handleEditCancel() {
    setEditingId(null)
  }

  return (
    <div className="sp-page">
      <h1 className="sp-title">Sample Parameters Screen</h1>

      <div className="sp-methodology">
        <label className="sp-methodology-label">Select Methodology</label>
        <select
          className="sp-select"
          value={methodology}
          onChange={(e) => setMethodology(e.target.value)}
        >
          <option value="Waterfall">Waterfall</option>
          <option value="Agile">Agile</option>
        </select>
      </div>

      <div className="sp-tabs">
        {TABS.map((tab) => (
          <button
            key={tab}
            className={`sp-tab${activeTab === tab ? ' sp-tab--active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="sp-panel">
        {activeTab === 'Support Costs' ? (
          <>
            <div className="sp-panel-header">
              <span className="sp-panel-title">Support Costs</span>
              <div className="sp-panel-controls">
                <div className="sp-search-wrap">
                  <span className="sp-search-icon">&#128269;</span>
                  <input
                    className="sp-search"
                    placeholder="Search all columns"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <button className="sp-btn sp-btn--danger" onClick={() => setSearch('')}>
                  Clear Filter
                </button>
                <button className="sp-btn sp-btn--success" onClick={handleAdd}>
                  + Add
                </button>
              </div>
            </div>

            <table className="sp-table">
              <thead>
                <tr>
                  <th>Actions</th>
                  <th>Items</th>
                  <th>Value</th>
                  <th>SDM Split</th>
                  <th>PS Split</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="sp-empty">No records found.</td>
                  </tr>
                ) : (
                  filtered.map((row) =>
                    editingId === row.id ? (
                      <tr key={row.id} className="sp-row--editing">
                        <td>
                          <button className="sp-action sp-action--save" onClick={() => handleEditSave(row.id)} title="Save">&#10003;</button>
                          <button className="sp-action sp-action--cancel" onClick={handleEditCancel} title="Cancel">&#10005;</button>
                        </td>
                        <td><input className="sp-cell-input" value={editValues.item} onChange={(e) => setEditValues((v) => ({ ...v, item: e.target.value }))} /></td>
                        <td><input className="sp-cell-input sp-cell-input--sm" value={editValues.value} onChange={(e) => setEditValues((v) => ({ ...v, value: e.target.value }))} /></td>
                        <td><input className="sp-cell-input sp-cell-input--sm" value={editValues.sdmSplit} onChange={(e) => setEditValues((v) => ({ ...v, sdmSplit: e.target.value }))} /></td>
                        <td><input className="sp-cell-input sp-cell-input--sm" value={editValues.psSplit} onChange={(e) => setEditValues((v) => ({ ...v, psSplit: e.target.value }))} /></td>
                      </tr>
                    ) : (
                      <tr key={row.id}>
                        <td>
                          <button className="sp-action sp-action--edit" onClick={() => handleEditStart(row)} title="Edit">&#9998;</button>
                          <button className="sp-action sp-action--delete" onClick={() => handleDelete(row.id)} title="Delete">&#128465;</button>
                        </td>
                        <td>{row.item}</td>
                        <td>{row.value}</td>
                        <td>{row.sdmSplit}</td>
                        <td>{row.psSplit}</td>
                      </tr>
                    )
                  )
                )}
              </tbody>
            </table>
          </>
        ) : (
          <div className="sp-placeholder">
            Content for <strong>{activeTab}</strong> — not yet implemented.
          </div>
        )}
      </div>
    </div>
  )
}
